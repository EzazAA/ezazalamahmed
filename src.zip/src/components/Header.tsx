import type React from "react"
import { FaUser, FaCode, FaProjectDiagram } from "react-icons/fa"
import styles from "./Header.module.css"

const Header: React.FC = () => {
  return (
    <header className={styles.header}>
      <nav className={styles.nav}>
        <ul className={styles.navList}>
          <li className={styles.navItem}>
            <a href="#about" aria-label="About" className={styles.navLink}>
              <FaUser />
            </a>
          </li>
          <li className={styles.navItem}>
            <a href="#skills" aria-label="Skills" className={styles.navLink}>
              <FaCode />
            </a>
          </li>
          <li className={styles.navItem}>
            <a href="#projects" aria-label="Projects" className={styles.navLink}>
              <FaProjectDiagram />
            </a>
          </li>
        </ul>
      </nav>
    </header>
  )
}

export default Header

