import type React from "react";
import styles from "./Projects.module.css";
import { ReactTag } from "./tags";
import { TailwindTag } from "./tags";
import { GithubTag } from "./tags";
import { LinkTag } from "./tags";

const Projects: React.FC = () => {
  const projects = [
    {
      title: "Ghostwipers Website",
      description:
        "This is a website for the ghostwipers brand, this is a mobile-first website",
      image:
        "https://github.com/EzazAA/ezazalamahmed/blob/main/preview-gw.png?raw=true",
      link: "https://ghostwipers.shop",
      github: "https://ezazaa.github.io/ghostwipers",
      tag: [<TailwindTag />, <ReactTag />],
    },
    {
      title: "AgroSmart website",
      description:
        "This is a website for my IoT-based project AgroSmart. You can view it below.",
      image:
        "https://github.com/EzazAA/ezazalamahmed/blob/main/preview-as.png?raw=true",
      link: "https://agro-smart-delta.vercel.app",
      github: "https://ezazaa.github.io/agro-smart",
      tag: [<TailwindTag />],
    },
    {
      title: "Terminal Cricket",
      description:
        "This is a Python project resembling a fun game called hand-cricket (CLI-based).",
      image:
        "https://github.com/EzazAA/ezazalamahmed/blob/main/preview-tc.png?raw=true",
      link: "https://github.com/ezazaa/terminal-cricket",
      tag: [],
    },
  ];

  return (
    <section id="projects" className={styles.projects}>
      <h2>Projects</h2>
      <div className={styles.projectsGrid}>
        {projects.map((project, index) => (
          <div key={index} className={styles.projectCard}>
            <img
              src={project.image || "/placeholder.svg"}
              alt={project.title}
            />
            <h3>{project.title}</h3>
            <p>{project.description}</p>
            <div className={styles.links}>
              <a href={project.link} target="_blank" rel="noopener noreferrer">
                <LinkTag />
              </a>
              <a href={project.github} target="_blank" rel="noopener noreferrer">
                <GithubTag />
              </a>
              {project.tag.length > 0 ? project.tag : <p></p>}
            </div>



          </div>
        ))}
      </div>
    </section>
  );
};

export default Projects;
