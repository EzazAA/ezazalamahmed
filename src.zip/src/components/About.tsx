import type React from "react"
import { FaGithub, FaLinkedin, FaEnvelope, FaInstagram } from "react-icons/fa"
import styles from "./About.module.css"


const About: React.FC = () => {
  return (
    <section id="about" className={styles.about}>
      <div className={styles.content}>
        <div className={styles.imageContainer}>
          <img src="https://github.com/EzazAA/ezazalamahmed/blob/main/photo.jpg?raw=true" alt="Your Name" className={styles.image} />
        </div>
        <div className={styles.text}>
          <h1>Ezaz Alam Ahmed | Web developer</h1>
          <p>
          <h4>Welcome to My Web Development Portfolio</h4>
          <p>
      Hi, I'm <strong>Ezaz Alam Ahmed</strong>, a passionate web developer with a focus on <strong>React.js</strong> and modern web technologies. I specialize in creating <strong>responsive, user-friendly web applications</strong> that are designed to solve real-world problems and enhance user experience. With a keen eye for <strong>front-end development</strong> and a deep understanding of <strong>web design principles</strong>, I craft <strong>visually appealing</strong> and <strong>performance-optimized</strong> websites. My goal is to deliver high-quality digital solutions that help businesses and individuals establish a strong online presence. Explore my portfolio to see how I can turn your ideas into functional, innovative web applications.
    </p>
          </p>
          <div className={styles.socialLinks}>
            <a href="https://github.com/ezaazaa" target="_blank" rel="noopener noreferrer">
              <FaGithub />
            </a>
            <a href="https://www.linkedin.com/in/ezaz-alam-ahmed-a6700a2b6/" target="_blank" rel="noopener noreferrer">
              <FaLinkedin />
            </a>
            <a href="https://instagram.com/ezazalamahmed" target="_blank" rel="noopener noreferrer">
              <FaInstagram />
            </a>
            <a href="mailto:your.email@example.com">
              <FaEnvelope />
            </a>
          </div>
          <p style={{fontSize:"1rem"}}>I would love to collaborate with you on a project</p>

        </div>
      </div>
    </section>
  )
}

export default About

