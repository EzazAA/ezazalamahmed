import React from "react";
import styles from "./tags.module.css";
import { DiGithub, DiReact } from "react-icons/di";
import { BiLink, BiLogoTailwindCss } from "react-icons/bi";

// Indivual Tag Components
export const ReactTag: React.FC = () => (
  <a href="https://react.dev" className={styles.Tag}>
    <DiReact />
    React
  </a>
);

export const TailwindTag: React.FC = () => (
  <a href="https://tailwindcss.com" className={styles.Tag}>
    <BiLogoTailwindCss />
    Tailwnd Css
  </a>
);

export const GithubTag: React.FC = () => (
  <a className={styles.Tag}>
    <DiGithub />
    Github
  </a>
);

export const LinkTag: React.FC = () => (
  <a className={styles.Tag}>
    <BiLink />
    Link
  </a>
);

// Exporting all components together
export default { ReactTag, TailwindTag, GithubTag, LinkTag };
