import type React from "react"
import {
    BiLogoReact,
    BiLogoJavascript,
    BiLogoNodejs,
    BiLogoPython,
    BiLogoGit
  } from "react-icons/bi";
  
import styles from "./Skills.module.css"

const Skills: React.FC = () => {
  const skills = [
    { name: "JavaScript", icon: <BiLogoJavascript color="white" className="icon"/> , description: "Programming language mainly for websites"},
    { name: "React", icon: <BiLogoReact color="white" className="icon"/> , description: "JavaScript based Library"},
    { name: "Node.js", icon: <BiLogoNodejs color="white" className="icon"/> , description: "JS based Backend"},
    { name: "Git", icon: <BiLogoGit color="white" className="icon"/> , description: "Version control"},
    { name: "Python", icon: <BiLogoPython color="white" className="icon"/> , description: "General level Programming language"},
  ]

  return (
    <section id="skills" className={styles.skills}>
      <h2>Skills</h2>
      <div className={styles.skillsGrid}>
        {skills.map((skill, index) => (
          <div key={index} className={styles.skillItem}>
            <div className={styles.img}>
            {skill.icon}
            </div>
            <div className={styles.desc}>
            <span>{skill.name}</span>
            <p>{skill.description}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

export default Skills

